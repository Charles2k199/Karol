import cv2
import os
import matplotlib.pyplot as plt
from tkinter import Tk
from tkinter.filedialog import askopenfilename

# Funkcja do wprowadzenia ceny
def wprowadz_cene(numer_prostokata):
    cena = input(f"Wprowadź cenę dla prostokąta {numer_prostokata}: ")
    return cena

# Funkcja do wyboru jednego zdjęcia
def wybierz_zdjecie():
    Tk().withdraw()  # Ukryj główne okno tkinter
    plik = askopenfilename(
        title="Wybierz zdjęcie",
        filetypes=[("Obrazy", "*.png *.jpg *.jpeg")]  # Akceptuj PNG i JPG
    )
    return plik

# Ścieżka do obrazu z ramkami
background_path = r"C:\\Users\\Char7es\\Desktop\\Projekt\\image.png"
background = cv2.imread(background_path)

# Sprawdzenie, czy obraz został wczytany
if background is None:
    print(f"Błąd: Nie udało się wczytać pliku '{background_path}'.")
    exit()

# Konwersja obrazu na skalę szarości i prógowanie
gray = cv2.cvtColor(background, cv2.COLOR_BGR2GRAY)
_, thresh = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY)  # Wykrywanie jasnych obszarów

# Znalezienie konturów prostokątów (dużych)
contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Lista dużych prostokątów
large_contours = []
for contour in contours:
    x, y, w, h = cv2.boundingRect(contour)
    if w > 300 and h > 150:  # Filtrujemy tylko duże prostokąty
        large_contours.append((x, y, w, h))

# Sortowanie dużych prostokątów po osi X
large_contours = sorted(large_contours, key=lambda c: c[0])

# Debugowanie: Wyświetlenie dużych prostokątów
print(f"Liczba dużych prostokątów: {len(large_contours)}")
debug_image = background.copy()
for x, y, w, h in large_contours:
    cv2.rectangle(debug_image, (x, y), (x + w, y + h), (0, 255, 0), 2)  # Zielone prostokąty dla dużych elementów

# Wyświetlenie obrazu z rozpoznanymi prostokątami
plt.figure(figsize=(12, 8))
plt.title("Rozpoznane duże prostokąty")
plt.imshow(cv2.cvtColor(debug_image, cv2.COLOR_BGR2RGB))
plt.show()

# Dodawanie zdjęć w dużych prostokątach
for i, (x, y, w, h) in enumerate(large_contours):
    print(f"Wybierz zdjęcie dla dużego prostokąta {i + 1} (pozycja: x={x}, y={y}, szerokość={w}, wysokość={h}).")
    img_path = wybierz_zdjecie()

    if not img_path:
        print("Nie wybrano zdjęcia. Pomijam ten prostokąt.")
        continue

    img = cv2.imread(img_path)
    if img is None:
        print(f"Błąd: Nie udało się wczytać zdjęcia '{img_path}'. Pomijam ten prostokąt.")
        continue

    resized_img = cv2.resize(img, (w, h))
    background[y:y+h, x:x+w] = resized_img

# Skupienie analizy na dolnej części obrazu (małe prostokąty)
height, width = gray.shape[:2]
roi = gray[int(height * 0.8):, :]  # Wycinamy dolne 20% obrazu

# Ponowne progowanie i kontury dla dolnej części
_, thresh_roi = cv2.threshold(roi, 240, 255, cv2.THRESH_BINARY)
contours_roi, _ = cv2.findContours(thresh_roi, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Lista małych prostokątów
small_contours = []
for contour in contours_roi:
    x, y, w, h = cv2.boundingRect(contour)
    if 100 < w < 400 and 30 < h < 150:  # Filtrujemy tylko małe prostokąty
        small_contours.append((x, y + int(height * 0.8), w, h))

# Sortowanie małych prostokątów po osi X
small_contours = sorted(small_contours, key=lambda c: c[0])

# Debugowanie: Wyświetlenie liczby wykrytych prostokątów
print(f"Liczba małych prostokątów: {len(small_contours)}")
for x, y, w, h in small_contours:
    cv2.rectangle(debug_image, (x, y), (x + w, y + h), (255, 0, 0), 2)  # Niebieskie prostokąty dla małych elementów

# Wyświetlenie obrazu z rozpoznanymi prostokątami
plt.figure(figsize=(12, 8))
plt.title("Rozpoznane małe prostokąty")
plt.imshow(cv2.cvtColor(debug_image, cv2.COLOR_BGR2RGB))
plt.show()

# Dodawanie cen w małych prostokątach
for i, (x, y, w, h) in enumerate(small_contours):
    print(f"Dodawanie ceny do prostokąta {i + 1} (pozycja: x={x}, y={y}, szerokość={w}, wysokość={h}).")
    cena = wprowadz_cene(i + 1)

    if not cena:
        print("Nie podano ceny. Pomijam ten prostokąt.")
        continue

    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 1.3
    font_color = (0, 0, 255)  # Kolor czerwony dla wyróżnienia
    thickness = 4

    # Dopasowanie współrzędnych tekstu
    text_size = cv2.getTextSize(cena, font, font_scale, thickness)[0]
    text_x = x + (w - text_size[0]) // 2  # Wyśrodkowanie tekstu w prostokącie
    text_y = y + (h + text_size[1]) // 2

    cv2.putText(background, cena, (text_x, text_y), font, font_scale, font_color, thickness)

# Zapisanie wynikowego obrazu
output_path = r"C:\\Users\\Char7es\\Desktop\\Projekt\\output.png"  # Ścieżka do wynikowego pliku
cv2.imwrite(output_path, background)
print(f"Wynikowy obraz zapisano jako: {output_path}")

# Wyświetlenie wynikowego obrazu
cv2.imshow("Result", background)
cv2.waitKey(0)
cv2.destroyAllWindows()
